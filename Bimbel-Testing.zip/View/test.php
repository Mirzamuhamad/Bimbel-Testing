<!DOCTYPE html>
<html>

<head>
    <!-- jQuery CDN -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js">
    </script>
    <!-- CSS CDN -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-datetimepicker/2.5.20/jquery.datetimepicker.min.css" />
    <!-- datetimepicker jQuery CDN -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-datetimepicker/2.5.20/jquery.datetimepicker.full.min.js">
    </script>

    <!-- Basic inline styling -->
    <style>
        body {
            text-align: center;
        }

        p {
            font-size: 25px;
            font-weight: bold;
        }
    </style>
</head>

<body>
    <h1 style="color:green">GeeksforGeeks</h1>
    <p>jQuery - Set datetimepicker on textbox click</p>

    <input type="text" class="datetimepicker" />
    <input type="text" class="datetimepicker" />

    <script type="text/javascript">
        $(".datetimepicker").each(function() {
            $(this).datetimepicker();
        });
    </script>
</body>

</html>